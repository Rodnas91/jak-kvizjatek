A rendszerfejlesztés technológiája és módszertana (BAI0168) tárgy beadandó feladata – Kvízjáték (JavaScript)

Olyan JavaScript alapú kvízjáték fejlesztése, amely lehetővé teszi a felhasználók számára, hogy kérdésekre válaszoljanak, pontokat gyűjtsenek, és visszajelzést kapjanak a teljesítményükről.
